package com.example.quizapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button startQuiz;
    EditText name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         startQuiz= findViewById(R.id.startQuiz);
         name=findViewById(R.id.editTextTextPersonName);
         startQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity();
            }
        });
    }

    private void openActivity() {
        Intent intent=new Intent(this,questionPage.class);
        intent.putExtra("name",name.getText().toString());
        startActivity(intent);
    }

}