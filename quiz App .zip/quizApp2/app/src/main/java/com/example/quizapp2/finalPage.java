package com.example.quizapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class finalPage extends AppCompatActivity {
    public TextView congo,yourScore,score;
    private Button finish,restart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String name=getIntent().getStringExtra("name");
        String scores=getIntent().getStringExtra("score");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_page);
        congo=findViewById(R.id.congratulations);
        yourScore=findViewById(R.id.yourScore);
        score=findViewById(R.id.Score);
        finish=findViewById(R.id.finish);
        restart=findViewById(R.id.restart);

        score.setText(scores+"/5....");
        congo.setText("Congratulations "+name);

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity();
            }
        });
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                System.exit(0);
            }
        });

    }
    private void openActivity() {
        finish();
        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }
}