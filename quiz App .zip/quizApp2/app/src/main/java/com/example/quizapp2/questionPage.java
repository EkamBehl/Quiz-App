package com.example.quizapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class questionPage extends AppCompatActivity {
    Integer score=0;
    Integer pos=0;
    Integer prog=0;
    public ProgressBar progress;
    public Integer option;
    private TextView question;
    public Button option1,option2,option3,submit;
    String name;
    private ArrayList<quizQuestion> quizArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_question_page);
        name=getIntent().getStringExtra("name");
        question=findViewById(R.id.question);
        option1=findViewById(R.id.option1);
        progress=findViewById(R.id.progressBar);
        option2=findViewById(R.id.option2);
        option3=findViewById(R.id.option3);
        submit=findViewById(R.id.submit);

        quizArray=new ArrayList<>();
        questionForm(quizArray);
        valAssign(pos);
        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option=1;
            }
        });
        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option=2;
            }
        });
        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                option=3;

            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(submit.getText().equals("Submit".trim().toLowerCase()))
                {

                    //Toast.makeText(questionPage.this, option.toString(), Toast.LENGTH_SHORT).show();
                    if(option.equals(1)){
                        if(quizArray.get(pos).getAnswer().equals(option1.getText())) {
                            score++;
                        }else{
                            option1.setBackgroundColor(Color.RED);
                        }

                    }
                    if(option.equals(2)){
                        if(quizArray.get(pos).getAnswer().equals(option2.getText())) {
                            score++;
                        }else{
                            option2.setBackgroundColor(Color.RED);
                        }

                    }
                    if(option.equals(3)){
                        if(quizArray.get(pos).getAnswer().equals(option3.getText())) {
                            score++;
                        }else{
                            option3.setBackgroundColor(Color.RED);
                        }

                    }
                    submit.setText("Next");

                    if(option1.getText().equals(quizArray.get(pos).getAnswer())){
                        option1.setBackgroundColor(Color.GREEN);
                    }
                    if(option2.getText().equals(quizArray.get(pos).getAnswer())){
                        option2.setBackgroundColor(Color.GREEN);
                    }
                    if(option3.getText().equals(quizArray.get(pos).getAnswer())){
                        option3.setBackgroundColor(Color.GREEN);
                    }
                }
                else{
                    pos=pos+1;
                    prog ++;
                    progress.setProgress(prog*20);


                    if(pos.equals(5)){
                        openActivity();
                    }
                    valAssign(pos);
                    option1.setBackgroundColor(Color.WHITE);
                    option2.setBackgroundColor(Color.WHITE);
                    option3.setBackgroundColor(Color.WHITE);
                    submit.setText("submit");


                }




            }

        });




    }

    private void valAssign(int pos) {
        question.setText(quizArray.get(pos).getQues());
        option1.setText(quizArray.get(pos).getOption1());
        option2.setText(quizArray.get(pos).getOption2());
        option3.setText(quizArray.get(pos).getOption3());


    }

    private void questionForm(ArrayList<quizQuestion> quizArray){
        quizArray.add(new quizQuestion("Which of following checks if player has clicked a button ?","OnClick","OnSelect","OnHover","OnClick"));
        quizArray.add(new quizQuestion("Which must be used for showing result?","textView","editText","showResult","textView"));
        quizArray.add(new quizQuestion("What is used to check equality?","==",".equal",".equals()",".equals()"));
        quizArray.add(new quizQuestion("What is this task?","UnitConverter","quizApp","calculator","quizApp"));
        quizArray.add(new quizQuestion("Can you create multiple Activities?","Not Sure","yes","nope","yes"));
    }
    private void openActivity() {
        Intent intents=new Intent(getApplicationContext(),finalPage.class);
        intents.putExtra("score",score.toString());
        intents.putExtra("name",name);

        startActivity(intents);
    }

}